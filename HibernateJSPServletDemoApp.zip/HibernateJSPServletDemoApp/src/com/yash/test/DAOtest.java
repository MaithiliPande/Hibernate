package com.yash.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yash.daohibernateimpl.EmployeeDAOImpl;
import com.yash.model.Employee;

public class DAOtest {
	Employee emp= null;

	@Test
	public void getEmployeeTest() {
		EmployeeDAOImpl empdao= new EmployeeDAOImpl();
		Employee employee=empdao.getEmployeeById("maithili");
		String actual=employee.getEmail();
		String expected="maithili.pande@yash.com";
		assertEquals(expected, actual);
	}
	
	@Test
	public void insertTest() {
		emp=new Employee();
		
	}

}
