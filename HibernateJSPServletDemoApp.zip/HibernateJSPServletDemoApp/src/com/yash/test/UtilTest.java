package com.yash.test;

import static org.junit.Assert.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.internal.SessionFactoryImpl;
import org.hibernate.internal.SessionImpl;
import org.junit.Test;

import com.yash.hibernate.util.HibernateUtil;

public class UtilTest extends HibernateUtil {

	@Test
	public void sessionFactoryTest() {
		SessionFactory sf=HibernateUtil.getSessionFactory();
		assertEquals(SessionFactoryImpl.class, sf.getClass());
		
	}
	
	@Test
	public void sessionTest() {
		Session session=openSession();
		assertEquals(SessionImpl.class, session.getClass());
	}

}
