package com.yash.hibernate.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {
	private static SessionFactory sessionFactory;
	static {
		getSessionFactory();
	}
	public static SessionFactory getSessionFactory() throws ExceptionInInitializerError {
		try {
			sessionFactory=new AnnotationConfiguration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
			return sessionFactory;
		}
		catch(Throwable ex){
			System.err.println("Initial Session Factory creation failure"+ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	public Session openSession() {
		return sessionFactory.openSession();
	}
	

}
