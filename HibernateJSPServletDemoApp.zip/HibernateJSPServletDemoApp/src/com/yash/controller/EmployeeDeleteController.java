package com.yash.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.service.EmployeeService;
import com.yash.serviceimpl.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeDeleteController
 */
@WebServlet("/EmployeeDeleteController")
public class EmployeeDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       EmployeeService employeeService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeDeleteController() {
       employeeService=new EmployeeServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long id=Long.parseLong(request.getParameter("id"));
		employeeService.deleteEmployee(id);
		request.getRequestDispatcher("welcome.jsp").forward(request, response);
	}

}
