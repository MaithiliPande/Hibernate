package com.yash.hibtest.main;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.yash.hibtest.pojo.ExternalProject;
import com.yash.hibtest.pojo.InternalProject;
import com.yash.hibtest.pojo.Project;

public class ApplicationStartUp {

	public static void main(String[] args) {
		
		Project project = new Project();
		project.setName("Test");
		
		InternalProject internalProject = new InternalProject();
		ExternalProject externalProject = new ExternalProject();
		
		internalProject.setName("Interview Scheduler");
		internalProject.setManagerName("Karnika Indras");
		
		externalProject.setName("John-Deere Tractor Monitoring");
		externalProject.setClientName("John Deere");
		
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		session.save(project);
		session.save(internalProject);
		session.save(externalProject);
		String hql= "update Project set name=:name where  id=:empid";
		Query query= session.createQuery(hql);
		query.setParameter("name", "Hibernate Project");
		query.setParameter("empid", 2);
		query.executeUpdate();
		
		String hql1= "from Project";
		Query query1= session.createQuery(hql1);
		List<Project>projects= query1.list();
		System.out.println("Project : ");
		for (Project proj : projects) {
			System.out.println("Pojects:"+proj);
		}
		
		
		
		session.getTransaction().commit();
		session.close();

	}

}
