package com.yash.hibtest.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.yash.hibtest.pojo.Employee;

public class ApplicationStartUp {

	public static void main(String[] args) {
		Employee employee=new Employee();
		
		@SuppressWarnings("deprecation")
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session= sessionFactory.openSession();
		
		employee.setId(101);
		employee.setName("Maihtili");
		employee.setContact("9763857839");
		employee.setAddress("Nagpur");
		
		session.beginTransaction();
		session.save(employee);//Transaction
		session.getTransaction().commit();
		session.close();
	}

}
