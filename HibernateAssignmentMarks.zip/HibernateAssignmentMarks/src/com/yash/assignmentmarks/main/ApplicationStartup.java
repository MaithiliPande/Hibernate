package com.yash.assignmentmarks.main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.yash.assignmentmarks.pojo.AssignmentMarks;

public class ApplicationStartup {

	public static void main(String[] args) {
		AssignmentMarks assignmentMarks= new AssignmentMarks();
		
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("****Welcome****");
		System.out.println("Enter id:");
		int id=sc.nextInt();
		assignmentMarks.setId(id);
		
		sc.nextLine();
		System.out.println("Enter name of assignment file:");
		String assignmentFile=sc.nextLine();
		assignmentMarks.setAssignment_file(assignmentFile);
		
		System.out.println("Enter total marks:");
		int totalMarks=sc.nextInt();
		assignmentMarks.setTotalMarks(totalMarks);
		
		System.out.println("Enter obtained marks:");
		int obtainedMarks=sc.nextInt();
		assignmentMarks.setObtainedMarks(obtainedMarks);
		
		System.out.println("Enter user id:");
		int userId=sc.nextInt();
		assignmentMarks.setUserid(userId);
		
		session.beginTransaction();
		session.save(assignmentMarks);
		session.getTransaction().commit();
		session.close();
		sc.close();
		
		

	}

}
