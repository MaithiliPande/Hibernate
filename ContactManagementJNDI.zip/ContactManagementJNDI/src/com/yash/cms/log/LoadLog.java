package com.yash.cms.log;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoadLog {

		// our log4j category reference
		  static final Logger log = Logger.getLogger(LoadLog.class);
		  static final String LOG_PROPERTIES_FILE = "src/resources/log4j.properties";

		  public static void main(String[] args)
		  {
		    // call our constructor
		    new LoadLog();

		    // Log4J is now loaded; try it
		    log.info("leaving the main method of Log4JDemo");
		  }

		  public LoadLog()
		  {
		    initializeLogger();
		    log.info( "Log4JExample - leaving the constructor ..." );
		  }

		  private void initializeLogger()
		  {
		    Properties logProperties = new Properties();

		    try
		    {
		      // load our log4j properties / configuration file
		      logProperties.load(new FileInputStream(LOG_PROPERTIES_FILE));
		      PropertyConfigurator.configure(logProperties);
		      log.info("Logging initialized.");
		    }
		    catch(IOException e)
		    {
		      throw new RuntimeException("Unable to load logging property " + LOG_PROPERTIES_FILE);
		    }
		  }

	}


