package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.domain.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class EditContactController
 */
@WebServlet("/EditContactController")
public class EditContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ContactService contactService=null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditContactController() {
        contactService=new ContactServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer id=Integer.parseInt(request.getParameter("id"));
		Contact contact=contactService.getContactDetails(id);
		request.setAttribute("contact", contact);
		request.getRequestDispatcher("contact.jsp").forward(request, response);
	}

}
