package com.yash.cms.dao;

import java.util.List;

import com.yash.cms.domain.Contact;

/**
 * This interface will perform operation related to contact
 * @author maithili.pande
 *
 */
public interface ContactDAO {
	public void insert(Contact contact);
	public List<Contact> list(Integer userid);
	public void delete(Integer id);
	public void update(Contact contact);
	public Contact getDetails(Integer id);
	public List<Contact> search(Integer userid, String searchText);
}
