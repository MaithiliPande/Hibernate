package com.yash.cms.util;
/**
 * This class will perform operation related to database like connection, 
 * disconnection, providing Prepared Statement object and ResultSet object.
 * This class will be responsible to have transaction complete operation as well 
 * like closing connection, Prepared statement object etc.
 * @author maithili.pande
 *
 */

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import org.apache.log4j.Logger;


public class DBUtil {
	private static Logger logger= Logger.getLogger(DBUtil.class);
	private static Context ctx=null;
	private static Connection con=null;
	private static PreparedStatement pstmt=null;
	
	/**
	 * This method should return the connection object based on url, username, password
	 * provided to DriverManager.getConnection() method
	 * @return connection object con
	 */
	public static Connection connection() {
		try {
			ctx=new InitialContext();
			DataSource ds=(DataSource) ctx.lookup("java:/comp/env/jdbc/contact_management");
			logger.info("DataSource object created:-"+ds);
			con=ds.getConnection();
			} catch (NamingException e) {
				logger.error("Data source object not created" );
				e.printStackTrace();
			} catch (SQLException e) {
				logger.error("Connection not obtained");
				e.printStackTrace();
			}
			logger.info("Connection object created:-"+con);
			return con;
		} 
		
	
	
	/**
	 * This method will return the PreparedStatement object based on the sql provided.
	 * This method should have call for connection because when you need transaction 
	 * that time you will require connection object 
	 * @sql is any query
	 * @return PreparedStatement object
	 */
	public static PreparedStatement createPreparedStatement(String sql) {
		connection();
		try {
			pstmt=con.prepareStatement(sql);
			logger.info("Prepared statement object created:-"+pstmt);
			
		} catch (SQLException e) {
			logger.error("Prepared statement object not created");
			e.printStackTrace();
		}
		return pstmt;
	}
	
	

}
