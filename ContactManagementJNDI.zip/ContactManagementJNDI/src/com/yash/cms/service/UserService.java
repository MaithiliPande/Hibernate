package com.yash.cms.service;

import com.yash.cms.domain.User;

/**
 * This will perform all services related task in user
 * @author maithili.pande
 *
 */
public interface UserService {
	/**
	 * This will register user
	 * @param user
	 */
	public void registerUser(User user);
	/**
	 * This will authenticate the user based on username and password
	 * @param username of user
	 * @param password of user
	 * @return user record if user is authenticated.
	 */
	public User userAuthentication(String username,String password);
}
