package com.yash.cms.domain;
/**
 * This class will work as a model object. Its use is to travel data from one layer to another layer
 * @author maithili.pande
 *
 */
public class Contact extends Person {
	/**
	 * user id of user
	 */
	public Integer userid;

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	

}
