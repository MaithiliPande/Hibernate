package com.yash.cms.daoimpl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.domain.User;
import com.yash.cms.util.DBUtil;
/**
 * This class is implementation of UserDAO interface
 * @author maithili.pande
 *
 */
public class UserDAOImpl implements UserDAO {
	private static Logger logger= Logger.getLogger(UserDAOImpl.class);
	User user=new User();
	private static Session session;
	@Override
	public void insert(User user) {
		SessionFactory sessionFactory = DBUtil.getSessionFactory();
		session = sessionFactory.openSession();
		try {
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.close();
		}
	}

	@Override
	public void delete(Integer userid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Integer userid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
