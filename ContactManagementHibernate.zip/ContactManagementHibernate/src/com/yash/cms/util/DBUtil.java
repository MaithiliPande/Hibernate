package com.yash.cms.util;
/**
 * This class will perform operation related to database like connection, 
 * disconnection, providing Prepared Statement object and ResultSet object.
 * This class will be responsible to have transaction complete operation as well 
 * like closing connection, Prepared statement object etc.
 * @author maithili.pande
 *
 */


import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class DBUtil {
	private static Logger logger= Logger.getLogger(DBUtil.class);
	private static SessionFactory sessionFactory;
	static {

		try {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
}
