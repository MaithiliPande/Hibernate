package com.yash.cms.test;

import com.yash.cms.util.DBUtil;

public class DBUtilPreparedStatementOperationTest {

	public static void main(String[] args) {
		String sql="insert into users(name,contact,username,password)"
				+ " values('maithili','9763857839','mai','123')";
		System.out.println(sql);
		DBUtil.createPreparedStatement(sql);

	}

}
