package com.yash.cms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.domain.User;
import com.yash.cms.service.UserService;
import com.yash.cms.util.DBUtil;

/**
 * This is implementation of UserService interface
 * @author maithili.pande
 *
 */
public class UserServiceImpl implements UserService {
	private static Logger logger= Logger.getLogger(UserServiceImpl.class);
	private UserDAO userDAO=null;
	
	public UserServiceImpl() {
		userDAO= new UserDAOImpl();
		logger.info("user service object created:"+userDAO);
	}
	@Override
	public void registerUser(User user) {
		userDAO.insert(user);
	}
//	@Override
//	public User userAuthentication(String username, String password) {
//		String sql="select * from users where username='"+username+"'and password='"+password+"'";
//		PreparedStatement pstmt=DBUtil.createPreparedStatement(sql);
//		User user=null;
//		try {
//			ResultSet rs=pstmt.executeQuery();
//			if(rs.next())
//			{
//				user=new User();
//				user.setId(rs.getInt("id"));
//				user.setName(rs.getString("name"));
//				user.setContact(rs.getString("contact"));
//				user.setEmail(rs.getString("email"));
//				user.setAddress(rs.getString("address"));
//				user.setStatus(rs.getInt("status"));
//				user.setRole(rs.getInt("role"));
//			}
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
//		return user;
//	}
//	
	

}
