package com.yash.cms.service;

import java.util.List;

import com.yash.cms.domain.Contact;

public interface ContactService {
	public void addContact(Contact contact);
	public List<Contact> listcontact(Integer userid);
	public void deleteContact(Integer id);
	public void updateContact(Contact contact);
	public Contact getContactDetails(Integer id);
	public List<Contact> searchContact(Integer userid, String searchText);
}
