package com.yash.hibtest.pojo;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="EmployeeDb")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private int id;
	@Column(name="Name")
	private String name;
	@Column(name="JoinDate")
	@Temporal(TemporalType.DATE)
	private Date joiningDate;
	@Column(name="Home Address")
	@Embedded
	private Address homeAddress;
	@Embedded
	@AttributeOverrides({@AttributeOverride (name="houseNo", column=@Column(name="Office_HouseNo")),
						@AttributeOverride (name="city", column=@Column(name="Office_City")),
						@AttributeOverride (name="state", column=@Column(name="Office_State")),
						@AttributeOverride (name="zip", column=@Column(name="Office_ZipCode")),
						 })
	private Address officeAddress;
	
	@Column(name="Desciption")
	@Lob
	private String shortDescription;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	public Address getOfficeAddress() {
		return officeAddress;
	}
	public void setOfficeAddress(Address officeAddress) {
		this.officeAddress = officeAddress;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	
	

}
