package com.yash.hibtest.main;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.yash.hibtest.pojo.Address;
import com.yash.hibtest.pojo.Employee;

public class ApplicatiponStartUp {

	public static void main(String[] args) {
		Employee employee=new Employee();
		Address homeAddress=new Address();
		Address officeAddress=new Address();
		SessionFactory sessionFactory= new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		employee.setName("Maithili");
		employee.setJoiningDate(new Date());
		
		homeAddress.setHouseNo(83);
		homeAddress.setCity("Nagpur");
		homeAddress.setState("Maharashtra");
		homeAddress.setZip("440025");
		employee.setHomeAddress(homeAddress);
		
		officeAddress.setHouseNo(101);
		officeAddress.setCity("Indore");
		officeAddress.setState("MP");
		officeAddress.setZip("425001");
		employee.setOfficeAddress(officeAddress);
		
		employee.setShortDescription("I am a trainee.");
		
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		
		//Retrieving data
		
//		employee=null;
//		session=sessionFactory.openSession();
//		employee=(Employee) session.get(Employee.class, 1);
//		session.close();
//		System.out.println(employee.getName());
		

	}

}
