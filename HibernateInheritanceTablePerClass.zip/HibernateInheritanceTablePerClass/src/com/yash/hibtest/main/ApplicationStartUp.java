package com.yash.hibtest.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.yash.hibtest.pojo.ExternalProject;
import com.yash.hibtest.pojo.InternalProject;
import com.yash.hibtest.pojo.Project;

public class ApplicationStartUp {

	public static void main(String[] args) {
		
		Project project = new Project();
		project.setName("Test");
		
		InternalProject internalProject = new InternalProject();
		ExternalProject externalProject = new ExternalProject();
		
		internalProject.setName("Interview Scheduler");
		internalProject.setManagerName("Karnika Indras");
		
		externalProject.setName("John-Deere Tractor Monitoring");
		externalProject.setClientName("John Deere");
		
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		session.save(project);
		session.save(internalProject);
		session.save(externalProject);
		session.getTransaction().commit();
		session.close();

	}

}
