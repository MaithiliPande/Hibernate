package com.yash.hibtest.main;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.yash.hibtest.pojo.Address;
import com.yash.hibtest.pojo.Employee;
import com.yash.hibtest.pojo.Project;

public class ApplicatiponStartUp {

	public static void main(String[] args) {
		Employee employee=new Employee();
		Address homeAddress=new Address();
		Address officeAddress=new Address();
		List<Address> addresses= new ArrayList<Address>();
		SessionFactory sessionFactory= new Configuration().configure().buildSessionFactory();
		Session session=sessionFactory.openSession();
		Project project1=new Project();
		Project project2=new Project();
		
		project1.setName("John-Deere");	
		project2.setName("Barter");	
		employee.getProjects().add(project1);
		employee.getProjects().add(project2);
		
		employee.setName("Maithili");
		employee.setJoiningDate(new Date());
		
		homeAddress.setHouseNo(83);
		homeAddress.setCity("Nagpur");
		homeAddress.setState("Maharashtra");
		homeAddress.setZip("440025");
		addresses.add(homeAddress);
		
		officeAddress.setHouseNo(101);
		officeAddress.setCity("Indore");
		officeAddress.setState("MP");
		officeAddress.setZip("425001");
		addresses.add(officeAddress);
		
		employee.setAddresses(addresses);
		
		employee.setShortDescription("I am a trainee.");
		
		project1.setEmployee(employee);
		project2.setEmployee(employee);
		
		session.beginTransaction();
		session.save(project1);
		session.save(project2);	
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		
		//Retrieving data
		
//		employee=null;
//		session=sessionFactory.openSession();
//		employee=(Employee) session.get(Employee.class, 1);
//		session.close();
//		System.out.println(employee.getName());
		

	}

}
